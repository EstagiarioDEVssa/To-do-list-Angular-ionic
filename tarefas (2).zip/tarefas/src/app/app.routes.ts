import { Routes } from '@angular/router';
import { HomePage } from './home/home.page';
import { NovaTarefaPage } from './nova-tarefa/nova-tarefa.page';

export const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', component: HomePage },
  { path: 'nova-tarefa', component: NovaTarefaPage },
];
