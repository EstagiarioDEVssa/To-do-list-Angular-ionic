
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { Router } from '@angular/router';
import { RouterModule } from '@angular/router';

import { addIcons } from 'ionicons';
import {
  add,
  trashOutline,
  checkmarkDoneOutline,
} from 'ionicons/icons';

@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
  standalone: true,
  imports: [IonicModule, CommonModule, FormsModule, RouterModule],
})
export class HomePage {
  tarefas: { nome: string; concluida: boolean }[] = [];

  constructor(private router: Router) {
    
    addIcons({
      add,
      'trash-outline': trashOutline, 
      'checkmark-done-outline': checkmarkDoneOutline, 
    });
  }

  ionViewWillEnter() {
    const salvas = localStorage.getItem('tarefas');
    if (salvas) this.tarefas = JSON.parse(salvas);
  }

  salvarTarefas() {
    localStorage.setItem('tarefas', JSON.stringify(this.tarefas));
  }

  marcarConcluida(tarefa: any) {
    tarefa.concluida = !tarefa.concluida;
    this.salvarTarefas();
  }

  removerTarefa(index: number) {
    this.tarefas.splice(index, 1);
    this.salvarTarefas();
  }

  novaTarefa() {
    this.router.navigate(['/nova-tarefa']);
  }
}