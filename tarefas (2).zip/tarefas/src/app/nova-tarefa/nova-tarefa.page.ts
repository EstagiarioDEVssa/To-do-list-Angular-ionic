import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { Router } from '@angular/router';

@Component({
  selector: 'app-nova-tarefa',
  templateUrl: './nova-tarefa.page.html',
  styleUrls: ['./nova-tarefa.page.scss'],
  standalone: true,
  imports: [IonicModule, CommonModule, FormsModule],
})
export class NovaTarefaPage {
  nomeTarefa: string = '';

  constructor(private router: Router) {}

  salvar() {
    if (!this.nomeTarefa.trim()) return;

    const tarefas = JSON.parse(localStorage.getItem('tarefas') || '[]');
    tarefas.push({ nome: this.nomeTarefa, concluida: false });
    localStorage.setItem('tarefas', JSON.stringify(tarefas));

    this.router.navigate(['/home']);
  }
}
